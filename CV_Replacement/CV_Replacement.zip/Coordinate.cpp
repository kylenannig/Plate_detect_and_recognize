#include "CV_Replacement.h"

Coordinate::Coordinate(int xCoordinate, int yCoordinate){
    x = xCoordinate;
    y = yCoordinate;
}

Coordinate::~Coordinate(){

}