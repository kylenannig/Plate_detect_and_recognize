//C style main file
//File created by Steven Anzivino 1/30/2021
//Class: Capstone  | On behalf of XMOS

//To compile:
//
//


#include "CV_Replacement.h"
#include <vector>
#include <iostream>

int main(){

    //test();
    
    return 0;
}


void TestBoundingRect(){
    
    int numberOfPoints = 5;
    int XLimit = 15;
    int YLimit = 20;

    std::vector<Coordinate> points;
    Coordinate *tempCoordinates = new Coordinate(0,0);
   

    for(int i = 0; i < numberOfPoints; i++){

        //Generates between 0 and limit.
        tempCoordinates->x = rand() % XLimit;
        tempCoordinates->y = rand() % YLimit;

        points.push_back(*tempCoordinates);
        //std::cout << "Coordinate??? " + points[i].x + ", " + points[i].y << std::endl;

    }


    std::cout << "Vector: ";
    for(int i = 0; i < numberOfPoints; i++){
        
        std::cout << points[i].x << ", " << points[i].y << " | "; // << std::endl;
    }
    std::cout << std::endl;

}
