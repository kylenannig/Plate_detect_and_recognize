#include "CV_Replacement.h"
#include <vector>
#include <iostream>



Image::Image(){

}

Image::~Image(){

}


void Image::cvtColor(){

}


void Image::Rectangle(Rect bounds, int thickness){

}

//From a vector of coordinates returns a rectangle encompasing all of the points.
Rect boundingRect(std::vector<Coordinate> CoordinateVector){
    int elements = CoordinateVector.size();

    //std::cout << "" std::endl;

    //int minX = ;
    int minY;
    int maxX;
    int maxY;

    for(int i = 0; i < elements; i++){
        
    }
}